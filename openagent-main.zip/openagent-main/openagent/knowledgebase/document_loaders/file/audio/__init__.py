from llama_hub.file.audio.base import AudioTranscriber

__all__ = ["AudioTranscriber"]
