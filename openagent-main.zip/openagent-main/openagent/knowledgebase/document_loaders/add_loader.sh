mkdir $1;
touch $1/base.py;
touch $1/README.md;
touch $1/__init__.py;
echo "\"\"\"Init file.\"\"\"" >  $1/__init__.py;
