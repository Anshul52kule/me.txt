# Instructions

This directory contains the library of available loaders. You may reference their implementations here and also add new ones! For full instructions on how to do so, [see here](https://github.com/emptycrown/llama-hub/tree/main).
