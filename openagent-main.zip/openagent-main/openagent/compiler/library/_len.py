import builtins

def len(value):
    ''' Length of the given argument
    '''
    return builtins.len(value)