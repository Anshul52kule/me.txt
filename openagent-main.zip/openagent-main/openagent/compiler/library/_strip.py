def strip(string):
    ''' Strip whitespace from the beginning and end of the given string.

    Parameters
    ----------
    string : str
        The string to strip.
    '''
    return string.strip()