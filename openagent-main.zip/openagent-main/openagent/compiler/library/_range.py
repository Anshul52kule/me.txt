import builtins

def range(*args, **kwargs):
    ''' Build a range of numbers.
    '''
    return builtins.range(*args, **kwargs)